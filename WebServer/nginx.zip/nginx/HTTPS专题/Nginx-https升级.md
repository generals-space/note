# Nginx-https升级

参考文章

[HTTPS(SSL) 升级实践手札](https://www.huangwenchao.com.cn/2015/07/https-update-log.html)

[Nginx的平滑重启和平滑升级](http://blog.chinaunix.net/uid-16879831-id-3313181.html)

[nginx报worker process 13666 exited on signal 11的错误](https://www.oliyo.cn/nginxbao-worker-process-13666-exited-on-signal-11de-cuo-wu/)

[nginx with secure_download 模块 出现worker process 20437 exited on signal 11的问题解决](http://blog.csdn.net/xuyaqun/article/details/5343021)